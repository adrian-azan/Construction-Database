﻿namespace DBExample
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.faultIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mPartNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mechFaultBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.s7183882DataSet = new DBExample.s7183882DataSet();
            this.mechFaultTableAdapter = new DBExample.s7183882DataSetTableAdapters.MechFaultTableAdapter();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tableAdapterManager = new DBExample.s7183882DataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mechFaultBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s7183882DataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.faultIDDataGridViewTextBoxColumn,
            this.mPartNumDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.mechFaultBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(246, 240);
            this.dataGridView1.TabIndex = 0;
            // 
            // faultIDDataGridViewTextBoxColumn
            // 
            this.faultIDDataGridViewTextBoxColumn.DataPropertyName = "faultID";
            this.faultIDDataGridViewTextBoxColumn.HeaderText = "faultID";
            this.faultIDDataGridViewTextBoxColumn.Name = "faultIDDataGridViewTextBoxColumn";
            // 
            // mPartNumDataGridViewTextBoxColumn
            // 
            this.mPartNumDataGridViewTextBoxColumn.DataPropertyName = "mPartNum";
            this.mPartNumDataGridViewTextBoxColumn.HeaderText = "mPartNum";
            this.mPartNumDataGridViewTextBoxColumn.Name = "mPartNumDataGridViewTextBoxColumn";
            // 
            // mechFaultBindingSource
            // 
            this.mechFaultBindingSource.DataMember = "MechFault";
            this.mechFaultBindingSource.DataSource = this.s7183882DataSet;
            // 
            // s7183882DataSet
            // 
            this.s7183882DataSet.DataSetName = "s7183882DataSet";
            this.s7183882DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mechFaultTableAdapter
            // 
            this.mechFaultTableAdapter.ClearBeforeFill = true;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button5.Location = new System.Drawing.Point(268, 217);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(88, 34);
            this.button5.TabIndex = 8;
            this.button5.Text = "Exit";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Exit_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Location = new System.Drawing.Point(268, 101);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 34);
            this.button2.TabIndex = 10;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Save_Click);
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CompanyTableAdapter = null;
            this.tableAdapterManager.ElectFaultTableAdapter = null;
            this.tableAdapterManager.EmploysTableAdapter = null;
            this.tableAdapterManager.EngineerTableAdapter = null;
            this.tableAdapterManager.EquipmentTableAdapter = null;
            this.tableAdapterManager.FaultTableAdapter = null;
            this.tableAdapterManager.MechFaultTableAdapter = this.mechFaultTableAdapter;
            this.tableAdapterManager.RepairsTableAdapter = null;
            this.tableAdapterManager.SpecializesInTableAdapter = null;
            this.tableAdapterManager.SpecialtyTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DBExample.s7183882DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(368, 263);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form7";
            this.Text = "MechFault";
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mechFaultBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s7183882DataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private s7183882DataSet s7183882DataSet;
        private System.Windows.Forms.BindingSource mechFaultBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn faultIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mPartNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button2;
        private s7183882DataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}