﻿namespace DBExample
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.s7183882DataSet = new DBExample.s7183882DataSet();
            this.electFaultBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.electFaultTableAdapter = new DBExample.s7183882DataSetTableAdapters.ElectFaultTableAdapter();
            this.faultIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ePartNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tableAdapterManager = new DBExample.s7183882DataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s7183882DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.electFaultBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.faultIDDataGridViewTextBoxColumn,
            this.ePartNumDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.electFaultBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(248, 171);
            this.dataGridView1.TabIndex = 0;
            // 
            // s7183882DataSet
            // 
            this.s7183882DataSet.DataSetName = "s7183882DataSet";
            this.s7183882DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // electFaultBindingSource
            // 
            this.electFaultBindingSource.DataMember = "ElectFault";
            this.electFaultBindingSource.DataSource = this.s7183882DataSet;
            // 
            // electFaultTableAdapter
            // 
            this.electFaultTableAdapter.ClearBeforeFill = true;
            // 
            // faultIDDataGridViewTextBoxColumn
            // 
            this.faultIDDataGridViewTextBoxColumn.DataPropertyName = "faultID";
            this.faultIDDataGridViewTextBoxColumn.HeaderText = "faultID";
            this.faultIDDataGridViewTextBoxColumn.Name = "faultIDDataGridViewTextBoxColumn";
            // 
            // ePartNumDataGridViewTextBoxColumn
            // 
            this.ePartNumDataGridViewTextBoxColumn.DataPropertyName = "ePartNum";
            this.ePartNumDataGridViewTextBoxColumn.HeaderText = "ePartNum";
            this.ePartNumDataGridViewTextBoxColumn.Name = "ePartNumDataGridViewTextBoxColumn";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button5.Location = new System.Drawing.Point(283, 149);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(88, 34);
            this.button5.TabIndex = 7;
            this.button5.Text = "Exit";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Exit_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Location = new System.Drawing.Point(283, 64);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 34);
            this.button2.TabIndex = 9;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Save_Click);
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CompanyTableAdapter = null;
            this.tableAdapterManager.ElectFaultTableAdapter = this.electFaultTableAdapter;
            this.tableAdapterManager.EmploysTableAdapter = null;
            this.tableAdapterManager.EngineerTableAdapter = null;
            this.tableAdapterManager.EquipmentTableAdapter = null;
            this.tableAdapterManager.FaultTableAdapter = null;
            this.tableAdapterManager.MechFaultTableAdapter = null;
            this.tableAdapterManager.RepairsTableAdapter = null;
            this.tableAdapterManager.SpecializesInTableAdapter = null;
            this.tableAdapterManager.SpecialtyTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DBExample.s7183882DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(382, 194);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form6";
            this.Text = "ElectricFault";
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s7183882DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.electFaultBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private s7183882DataSet s7183882DataSet;
        private System.Windows.Forms.BindingSource electFaultBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn faultIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ePartNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button2;
        private s7183882DataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}